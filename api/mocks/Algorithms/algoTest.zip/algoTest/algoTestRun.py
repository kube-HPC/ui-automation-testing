def start(args):
    numbers = args.get("numbers", [8, 3, 5, 1, 9, 2])

    print("Before sorting:", numbers)

    n = len(numbers)

    for i in range(n):
        for j in range(0, n - i - 1):
            if numbers[j] > numbers[j + 1]:
                numbers[j], numbers[j + 1] = numbers[j + 1], numbers[j]

    print("After sorting:", numbers)

    return {
        "result": numbers,
        "algorithm": "Bubble Sort"
    }